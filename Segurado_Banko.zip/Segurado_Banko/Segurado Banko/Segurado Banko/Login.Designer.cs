﻿namespace Segurado_Banko
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPINCode = new System.Windows.Forms.Label();
            this.txtTruePINCode = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txtPINCode = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblPINCode
            // 
            this.lblPINCode.AutoSize = true;
            this.lblPINCode.BackColor = System.Drawing.Color.Transparent;
            this.lblPINCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPINCode.Location = new System.Drawing.Point(125, 141);
            this.lblPINCode.Name = "lblPINCode";
            this.lblPINCode.Size = new System.Drawing.Size(125, 52);
            this.lblPINCode.TabIndex = 0;
            this.lblPINCode.Text = "• • • •";
            // 
            // txtTruePINCode
            // 
            this.txtTruePINCode.BackColor = System.Drawing.Color.LimeGreen;
            this.txtTruePINCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTruePINCode.Location = new System.Drawing.Point(288, 678);
            this.txtTruePINCode.Name = "txtTruePINCode";
            this.txtTruePINCode.Size = new System.Drawing.Size(87, 19);
            this.txtTruePINCode.TabIndex = 1;
            this.txtTruePINCode.TextChanged += new System.EventHandler(this.txtTruePINCode_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Location = new System.Drawing.Point(66, 268);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(62, 64);
            this.panel1.TabIndex = 3;
            this.panel1.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(156, 268);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(62, 64);
            this.panel2.TabIndex = 3;
            this.panel2.Click += new System.EventHandler(this.panel2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Location = new System.Drawing.Point(247, 268);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(62, 64);
            this.panel3.TabIndex = 3;
            this.panel3.Click += new System.EventHandler(this.panel3_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Location = new System.Drawing.Point(66, 356);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(62, 64);
            this.panel4.TabIndex = 3;
            this.panel4.Click += new System.EventHandler(this.panel4_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Location = new System.Drawing.Point(156, 356);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(62, 64);
            this.panel5.TabIndex = 3;
            this.panel5.Click += new System.EventHandler(this.panel5_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Location = new System.Drawing.Point(247, 356);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(62, 64);
            this.panel6.TabIndex = 3;
            this.panel6.Click += new System.EventHandler(this.panel6_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.Location = new System.Drawing.Point(66, 450);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(62, 64);
            this.panel7.TabIndex = 3;
            this.panel7.Click += new System.EventHandler(this.panel7_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Location = new System.Drawing.Point(156, 450);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(62, 64);
            this.panel8.TabIndex = 3;
            this.panel8.Click += new System.EventHandler(this.panel8_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.Location = new System.Drawing.Point(247, 450);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(62, 64);
            this.panel9.TabIndex = 3;
            this.panel9.Click += new System.EventHandler(this.panel9_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.Location = new System.Drawing.Point(156, 540);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(62, 64);
            this.panel10.TabIndex = 3;
            this.panel10.Click += new System.EventHandler(this.panel10_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(66, 546);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 50);
            this.button1.TabIndex = 4;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(247, 546);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(62, 50);
            this.button2.TabIndex = 4;
            this.button2.Text = ">";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtPINCode
            // 
            this.txtPINCode.BackColor = System.Drawing.Color.LimeGreen;
            this.txtPINCode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPINCode.Location = new System.Drawing.Point(288, 653);
            this.txtPINCode.Name = "txtPINCode";
            this.txtPINCode.Size = new System.Drawing.Size(87, 19);
            this.txtPINCode.TabIndex = 1;
            this.txtPINCode.TextChanged += new System.EventHandler(this.txtTruePINCode_TextChanged);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Segurado_Banko.Properties.Resources.login;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(375, 700);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtPINCode);
            this.Controls.Add(this.txtTruePINCode);
            this.Controls.Add(this.lblPINCode);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPINCode;
        private System.Windows.Forms.TextBox txtTruePINCode;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtPINCode;
    }
}