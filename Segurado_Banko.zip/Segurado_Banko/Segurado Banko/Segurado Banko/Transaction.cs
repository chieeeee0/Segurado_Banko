﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Segurado_Banko
{
    public class Transaction
    {
        public string Description { get; set; }
        public string Amount { get; set; }
        public DateTime Date { get; set; }
    }

}
